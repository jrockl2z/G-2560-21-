/**
 * Menu state.
 */
function Menu() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Menu.prototype = proto;

Menu.prototype.preload = function() {
	this.load.pack("start", "assets/assets-pack.json");
};

Menu.prototype.create = function() {
	this.stage.backgroundColor = "#FF6699";
	this.background = this.game.add.sprite(0,0,'Nameq'); 

	var cx=this.world.centerX;
	var mstart = this.add.sprite(cx,180+250,"mstart");
	var mteam = this.add.sprite(cx,180+450,"mteam");

	mstart.anchor.set(0.5, 0.5);
	mteam.anchor.set(0.5, 0.5);
	
	mstart.inputEnabled = true;
	mteam.inputEnabled = true;
	
    mstart.events.onInputDown.add(this.startLevel, this);
    mteam.events.onInputDown.add(this.startTeam, this);    
};
Menu.prototype.startLevel = function(){
	this.game.state.start("Level");
}
Menu.prototype.startTeam = function(){
	this.game.state.start("Team");
}