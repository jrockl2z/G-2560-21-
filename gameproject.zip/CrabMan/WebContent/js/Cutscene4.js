/**
 *
 */
function Cutscene4 () {
	
}

