/**
 *
 */
function Cutscene2 () {
	
}

