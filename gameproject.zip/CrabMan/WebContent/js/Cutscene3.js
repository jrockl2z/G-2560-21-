/**
 *
 */
function Cutscene3 () {
	
}

