/**
 *
 */
function Cutscene1 () {
	
}

